let frutas = ['abacaxi', 'banana', 'maçã', 'laranja', 'abacate', 'limão', 'tamarindo'];

for (let fruta of frutas) {
    console.log(fruta);
}