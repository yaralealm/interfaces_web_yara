let frutas = ['abacaxi', 'banana', 'maçã', 'laranja', 'abacate', 'limão', 'tamarindo'];

for (let i=0; i < frutas.length; i++) {
    let fruta = frutas[i];
    console.log(fruta);
}

