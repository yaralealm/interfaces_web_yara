let inteiros = [];

for (let i=1; i <=10; i++) {
    inteiros.push(i); 
}

console.log(inteiros.join(' - '));